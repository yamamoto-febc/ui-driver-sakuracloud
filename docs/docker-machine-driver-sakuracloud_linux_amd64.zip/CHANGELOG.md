# Changelog

## 1.5.0 (2021-04-07)

- Update development environments #78 (yamamoto-febc)
- Update dependencies #77 (yamamoto-febc)

## 1.4.1 (2019-10-11)

* libsacloud v2 #71 (yamamoto-febc)
* go 1.13 #72 (yamamoto-febc)
* Update Dockerfile - use alpine 3.10 #73 (yamamoto-febc)
* APIClientへのパスワードフィールドの追加 #74 (yamamoto-febc)

## 1.4.0 (2018-11-09)

* IPアドレスをストレージに保存 #69

## 1.3.0 (2018-10-12)

* 新プラン対応 #65

## 1.2.0 (2018-07-18)

* デフォルトOS変更 #62

## 1.1.0 (2017-12-14)

* CoreOS対応 #59

## 1.0.0 (2017-11-27)

* v1.0.0 #56 (yamamoto-febc)
